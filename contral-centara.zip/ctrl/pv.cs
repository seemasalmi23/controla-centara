﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContorlCenter
{
    class pv
    {
        public static bool Desukutop = false;
        public static int Draw_X = 0;
        public static int Draw_Y = 0;
        public static int Step_Length = 200;
        public static float Chara_Size = 10;
        public static Color chara_color = Color.DeepPink;
        public static string Img_path = "";

        public static int bg_X = 0;
        public static int bg_Y = 0;
        public static int bg_chaca_size = 0;

    }
}
